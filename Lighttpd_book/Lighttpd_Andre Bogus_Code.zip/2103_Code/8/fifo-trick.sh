# create a FIFO in our lighttpd chroot environment
mkfifo /lighttpd/etc/backend.socket

# make our lighttpd user/group own the fifo to get access
chown lighttpd:lighttpd /lighttpd/etc/backend.socket

# create a hard link into our backend environment
ln /lighttpd/etc/backend.socket /backend/etc/lighttpd.socket

# make our backend user/group own the linked fifo to get access
chown backend:backend /backend/etc/lighttpd.socket
