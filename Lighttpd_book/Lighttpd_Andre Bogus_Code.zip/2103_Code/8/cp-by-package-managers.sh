# for rpm-using distributions, e.g. RedHat, CentOS, Fedora, SuSE, etc.
#rpm -q �-filesbypkg lighttpd | while read x y; do # x == �lighttpd�
#  if [! -d $y ]; then cp $y /lighttpd$y; fi
#done

# for debian-inspired systems using dpkg
#dpkg -L lighttpd | while read x; do 
#  if [! -d $x ]; then cp $x /lighttpd$x; fi
#done

# or apt � �apt-file list� is the same as �dpkg -L�
#apt-file list lighttpd | while read x; do 
#  if [! -d $x ]; then cp $x /lighttpd$x; fi
#done
