#!/bin/env python
import os

def allSUIDfiles(path="."):
	for (root, dirs, files) in os.walk(path):
		for name in files:
			filepath = os.path.join(root, name) 
			if os.stat(filepath)[0] & (1 << 11) > 0:
				yield filepath

if __name__ == "__main__":
	print "Searching SUID files in this directory recursively:"
	for f in allSUIDfiles(): print f