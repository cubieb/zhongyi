#!/bin/bash
# Change FILES according to your system, some systems name the
# library files different than .so � ls /usr/lib/mod* may help.
FILES=�/usr/sbin/lighttpd /usr/lib/mod_*.so�
for FILE in $FILES
do
	mkdir -p /lighttpd${FILE%/*}
	cp $FILE /lighttpd$FILE
	ldd $FILE | while read A B C D
	do
		# check if there is an entry
		if [ �not� == �$A� ]
		then
			echo �$FILE: not a dynamic executable�
		elif [ -z $C ]
		then
			mkdir -p /lighttpd${A%/*}
			cp $A /lighttpd$A
		else
			mkdir -p /lighttpd${C%/*}
			cp $C /lighttpd$C
		fi
	done
done
