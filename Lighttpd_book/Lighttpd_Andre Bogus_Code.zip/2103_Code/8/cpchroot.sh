#!/bin/bash
cat $1 | while read n; do echo cp $n /lighttpd$n; done