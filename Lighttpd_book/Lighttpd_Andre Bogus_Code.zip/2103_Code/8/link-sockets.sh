for name in $(ls /backend/etc/lighttpd.socket*); do
  target=/lighttpd/etc/backend${name#/backend/etc/lighttpd}
  ln $name $target
  chown lighttpd:lighttpd $target
done
