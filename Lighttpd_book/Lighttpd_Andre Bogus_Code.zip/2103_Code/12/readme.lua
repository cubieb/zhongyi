local root = lighty.env["physical.doc-root"]
lighty.content = {"<html><head><title>README</title></head><body>",
	"<pre>", {filename=root.."README"}, "</pre></body></html>"}
	