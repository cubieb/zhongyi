--[[ cgi.lua (C) Andre Bogus ]]

local function uridecode(k)
	return (k or ""):gsub("[\r%+]",
		{['\r']='\n', ["+"]=" "}):gsub("%%(%x%x)", function(h)
			return string.char(tonumber(h,16))
		end)
end

local function readOnce(e)
	bytes = math.min(e.bytes, 8192)
	e.buf = e.buf .. io.read(bytes)
	e.bytes = e.bytes - bytes
end

local function readUntilMatches(e, b)
	while e.bytes > 0 and not e.buf:match(b) do readOnce(e) end
end

local function skipUntilMatches(e, b)
	while e.bytes > 0 and not e.buf:match(b) do 
		readOnce(e)
		e.buf = e.buf:sub(math.max(#e.buf - 8192 + #b,1))
	end
	e.buf = e.buf:match("(".. b .. ".*)")
end

local function include(incl, f)
	local t = type(incl)
	if t == "function" then return incl(f) end
	if t == "table" then 
		return incl[f] ~= nil 
	end
	return true	
end

local function _init()
	post = {}
	_postcached = false
	local _post = {}
	setmetatable(post, _post)

	function _post:__index(key)
		if not _postcached then
			for k, v in post(includes) do self[k] = v end
			_postcached = true
		end
		return rawget(self, key)
	end

	function _post:__call(incl)
		local b, k = (os.getenv("CONTENT_TYPE") or ""):match("boundary=(%S+)")
		if b then b, k = requote(b), "\r?\n\r?\n" 
		else b, k = "&", "=" end
		return function(e, _)
			while true do
				readUntilMatches(e, e.k) -- key-value-separator
				key = e.buf:match(e.b .. "(.-)" .. e.k)
				if key == nil then return nil end
				if e.k ~= "=" then key = key:match('name="([^"]*)"') end
				e.buf = e.buf:match(e.k .. "(.*)")
				if include(incl, key) then break end
				skipUntilMatches(e, e.b)
			end
			if #e.buf < 8192 and not e.buf:match(e.b) then readOnce(e) end
			if not e.buf:match(e.b) then
				name, file = mktemp()
				while true do
					readOnce(e)
					local x = math.max(0, #e.buf - #e.b)
					file:write(e.buf:sub(1, x))
					e.buf = e.buf:sub(x + 1)
					if e.buf:match(e.b) then
						file:write(e.buf:match("(.-)\n?" .. e.b))
						e.buf = e.buf:match(e.b.."(.*)")
						file:close()
						return key, {filename=name}
					end
				end
				--readToTmpUntilMatches(e, e.b) -- boundary
			end
			value = e.buf:match("(.-)" .. e.b)
			e.buf = e.buf:sub(#value)
			if e.k ~= "=" then value = value:match('^(.-)\n?$') end
			return uridecode(key), uridecode(value)
		end, {bytes=tonumber(os.getenv("CONTENT_LENGTH") or 0),	b=b, k=k, buf=""}
	end

	get = {}
	_getcached = false
	local _get = {}
	setmetatable(get, _get)
	
	function _get:__index(key)
		if not _getcached then
			for k, v in get(includes) do
				self[uridecode(k)] = uridecode(v)
			end
			_getcached = true
		end
		return rawget(self, key)
	end
	
	function _get:__call(incl)
		local q = os.getenv("QUERY_STRING") or ""
		return q:gmatch("([^&=]+)=([^&=]*)")
	end
end

local _require = require
_G.require = function(...)
	local args = {...}
	local name = args[1]
	if name ~= "cgi" then
		return _require(unpack(args))
	end
	_init() -- reinit
	return _G["cgi"]
end

module("cgi", package.seeall)

includes = {}

uridecode = uridecode

function requote(p)
	return string.gsub(p, "([%^%$%(%)%%%.%[%]%*%+%-%?])", "%%%1")
end

function mktmp() -- open a tmpfile securely
	local tmpname = os.tmpname()
	local tmpfile = io.open(tmpname, "a+b")
	while tmpfile:seek("end", 0) ~= 0 do
		tmpfile:close()
		tmpname = os.tmpname()
		tmpfile = io.open(tmpname, "a+b")
	end
	return tmpname, tmpfile
end

_init()