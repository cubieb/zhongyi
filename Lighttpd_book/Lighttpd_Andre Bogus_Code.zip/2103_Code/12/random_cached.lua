-- caching file contents in _G
source = "/var/www/random/files"
if _G.filecache == nil or
		lighty.stat(source).st_mtime > _G.filecache.time then
	_G.filecache = {time=os.time()}
	for f in io.lines(source) do
		if f ~= nil and f:gsub("%s", "") ~= "" then
			table.insert(_G.filecache, (f or ""):gsub("%s*$", ""))
		end
	end
end
dir = "/var/www/random/"
lighty.header["Content-Type"] = "image/png"
lighty.content = {{filename=dir .. files[math.random(#_G.filecache)]}}
return 200
