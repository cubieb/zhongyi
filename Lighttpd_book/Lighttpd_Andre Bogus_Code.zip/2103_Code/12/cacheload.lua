magnet.cache["myscript"] = { mtime=os.time(), hits=1,
	script=loadfile("myscript.lua") } -- or loadstring or function
