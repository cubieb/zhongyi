function range(f, t)
	return function(_, x) return x<t and x+1 or nil end, nil, f�1
end -- use with: for i in range(1, 10) do ... end

-- for example:
for i in range(1, 10) do print(i) end