print([[Status: 200
Content-Type: text/html

<html><head><title>Congratulations!</title></head><body>Lua appears to work.</body></html>]])