a = {} -- creates an empty table

b = {1, "a", function() return 1 end} -- a table used as array
-- as we can see, it can hold objects of any type

c = {a=1, b=2, ["c"]=4, [5]=6} -- both syntaxes for keyed tables

d = {{a=1}, {a=2}, i=function(...) end} -- tables can be nested

e = d[1] -- e == {a=1}; Lua counts from one instead of zero!!!

f = d["a"] -- f == nil
-- this also explains while nil can not be a key for a keyed table