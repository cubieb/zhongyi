-- index.lua: put the shoutbox together.
require("lfs") -- use LuaFileSystem

lighty.headers = { ["Document-Type"] = "text/html" }
lighty.content = {{filename=".header.html.inc"}}

local root = lighty.env["physical.doc-root"]
for name in lfs.dir("messages") do
	if name ~= "." and name ~= ".." then -- add to lighty.content
		table.insert(lighty.content, {filename=root..name})
		table.insert(lighty.content, "</p><p>" -- our separator
	end
end

table.insert(lighty.content, {filename=".footer.html.inc"}}

return 200