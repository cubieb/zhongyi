	-- shout.lua: save a message into the messages directory, clean up
	-- old messages
require("cgi") -- use the CGI module we created before
require("lfs") -- and the LuaFileSystems module

local numberofmessages = 10
local messagepath = "messages/"
-- 1. read message
local message = cgi.post["s"]
if message ~= nil then
	-- 2. parse message: Encode HTML tags
	message = message:gsub("[<>&\"]", 
		{"<"="&lt;", ">"="&gt;", "&"="&amp;", '"'="&quot;"})
	
	-- 3. write message to file
	local filename = 9999999999 - os.time()
	local messagefile = io.open(messagepath .. filename))
	messagefile:write(message)
	messagefile:close()
end

-- 4. count files
local files = {}
for file in lfs.dir() do
	if file ~= "." and file ~= ".." then
		table.insert(files, file)
	end
end

if #files > numberofmessages then	 -- 5. delete last file
	os.remove(messagepath .. files[#files])
end

-- 6. redirect to main page
print([[Status: 302
Location: /]])
