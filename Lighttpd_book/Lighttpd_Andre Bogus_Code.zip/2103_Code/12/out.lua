header = {["Content-Type"]="text/html"}
content = {}
size = 0
_print = print
function print(...)
	for _, v in pairs({...}) do
		local tmp = tostring(v)
		size = size + #tmp
		table.insert(content, tmp)
	end
end
function out()
	header["Content-Length"] = size + #content -- for newlines
	for k, v in pairs(header) do _print(k .. ": " .. v) end
	print("\n")
	for _, v in ipairs(content) do _print(v) end
end
