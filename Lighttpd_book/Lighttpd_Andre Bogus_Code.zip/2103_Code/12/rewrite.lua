lighty.env["request.uri"] = string.gsub(
	lighty.env["request.uri"] or "", "foo", "bar")
return lighty.RESTART_REQUEST
