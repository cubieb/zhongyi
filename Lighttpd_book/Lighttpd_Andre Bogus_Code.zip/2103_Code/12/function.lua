function x(y) -- This is a comment
	local a = y * y
	return y + 1, a - 1 -- ";" at the end of a statement is optional
end --[[ This is a multiline comment 
we can use our function as a, b = x(0) ]]
