-- the following definitions are needed to run the examples from the book:
function condition() return true end
function block(i) print("Block", i) end
function block2() print("Block2") end
-- here are the examples:

if condition() then block() end

if condition() then block() else block2() end

for i = 1, 3 do block(i) end -- block(1); block(2); block(3)

for i = 1, 5, 2 do block(i) end -- block(1); block(3); block(5)

for key, value in pairs({a="b", b="c"}) do 
	io.write(k.."="..v..",") -- pairs is an iterator function.
end -- writes: "a=b,b=c" to standard output

i = 0
while i < 5 do i = i + 1 end -- increment i until 5

repeat i = i + 1 until i > 10 -- and on until 10

while (true) break end -- cheating ourselves out of the infinite loop