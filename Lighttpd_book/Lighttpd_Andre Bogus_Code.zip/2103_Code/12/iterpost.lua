-- the following definitions are needed to run the example from the book:
require("requote")

function uridecode(k)
	return (k or ""):gsub("%%(%x%x)", function(h) 
	  return string.char(tonumber(h,16)) end):gsub("[\r%+]",
	  {['\r']='\n', ["+"]=" "})
end
-- here is the example:

function readUntilMatches(e, b)
	while e.bytes > 0 and not e.buf:match(b) do
		bytes = math.min(e.bytes, 8192)
		e.buf = e.buf .. io.read(bytes)
		e.bytes = e.bytes - bytes
	end
end

function iterpost()
	return function(e, _)
		readUntilMatches(e, kv) -- key-value-separator
		key = e.buf:match(e.b .. "(.-)" .. kv)
		if key == nil then return nil end
		e.buf = e.buf:match(kv .. "(.*)")
		readUntilMatches(e, e.b) -- boundary
		value = e.buf:match("(.-)" .. e.b)
		e.buf = e.buf:sub(#value)
		return uridecode(key:match('name="(.-)"')), uridecode(value)
	end, {bytes=tonumber(os.getenv("CONTENT_LENGTH") or 0),
			   b="\n"..requote((os.getenv("CONTENT_TYPE") or ""
			):match("boundary=(%S*)")), kv="\r?\n\r?\n", buf=""}
end