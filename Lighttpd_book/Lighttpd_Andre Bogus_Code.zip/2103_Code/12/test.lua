lighty.headers = { ["Document-Type"] = "text/html" }
lighty.content = {"<html><head><title>mod_magnet</title></head>",
	"<body>It's alive!</body></html>"}
return 200
