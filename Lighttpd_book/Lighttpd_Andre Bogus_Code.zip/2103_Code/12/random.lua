-- rewrite based on random number
dir = "/var/www/random/"
files = {"a.png", "x.png", "not.png", "else.png"}
lighty.header["Content-Type"] = "image/png"
lighty.content = {{filename=dir .. files[math.random(#files)]}}
return 200
