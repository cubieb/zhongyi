-- the following definitions are needed to run the examples from the book:
mytable = { x=-84 }
-- here are the examples:

function mytable:myfunction(a) return self.x + a end
-- function mytable.myfunction(self, a)...

print(mytable:myfunction(42)) -- == mytable.myfunction(mytable, 42)

-- added the print to make the -42 visible