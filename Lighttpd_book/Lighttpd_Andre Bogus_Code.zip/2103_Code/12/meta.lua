mytable, mymeta = {}, {} -- multi-assignment works, too.
setmetatable(mytable, mymeta)
globmeta = getmetatable(_G) -- yes, we can even mess with _G.