-- redirect to first found
if lighty.stat(lighty.env["uri.path"]) == nil then
	searchPatterns = {"media/?", "other/?", "cache/?"}
	for _, v in ipairs(searchPatterns) do
		local path = string.gsub(v, "%?", lighty.env["uri.path"])
		if lighty.stat(path) ~= nil then
			lighty.request["Location"] = path
			return 302
		end
	end
	return 400
end
