function requote(p)
	return (p or ""):gsub("([%^%$%(%)%%%.%[%]%*%+%-%?])", "%%%1")
end
