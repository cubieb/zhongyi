-- the following definitions are needed to run the example from the book:
require("requote")

function uridecode(k)
	return (k or ""):gsub("%%(%x%x)", function(h) 
	  return string.char(tonumber(h,16)) end):gsub("[\r%+]",
	  {['\r']='\n', ["+"]=" "})
end
-- here is the example:

post, q = {}, io.read(os.getenv("CONTENT_LENGTH") or 0)
for k, v in q:gmatch("([^&=]+)=([^&=]*)") do
	post[uridecode(k)] = uridecode(v)
end