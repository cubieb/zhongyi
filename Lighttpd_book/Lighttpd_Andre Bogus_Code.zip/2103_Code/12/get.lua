require("requote") -- added so it might work.

function uridecode(k)
	return (k or ""):gsub("%%(%x%x)", function(h) 
	  return string.char(tonumber(h,16)) end):gsub("[\r%+]",
	  {['\r']='\n', ["+"]=" "})
end
get, q = {}, os.getenv("QUERY_STRING") or ""
for k, v in q:gmatch("([^&=]+)=([^&=]*)") do
	get[uridecode(k)] = uridecode(v)
end