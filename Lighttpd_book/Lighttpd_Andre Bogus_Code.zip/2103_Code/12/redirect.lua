lighty.header[�Location�] = string.gsub(
	lighty.env["request.uri"] or "", "foo", "bar")
return 302 -- moved temporarily
