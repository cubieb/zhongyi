require("md5") -- from Kepler
require("mime") -- from LuaSocket
local sessionId = os.getenv("HTTP_COOKIE"):match("$id=[^&=]*")
if sessionId == nil then
	sessionId = mime.b64(md5.sum(os.getenv("REMOTE_ADDRESS")..
		tostring(math.random())
	header["Set-Cookie"] = "id="..sessionId..";maxAge=3600"
end
