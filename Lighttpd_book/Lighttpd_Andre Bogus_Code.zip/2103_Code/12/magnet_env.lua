lighty={
	["RESTART_REQUEST"]=99, -- A constant for returning to LightTPD 
	header={ --[[ The headers go here ]] }, 
	request={
		["Accept"]="text/xml,application/xml,application/xhtml+xml," .. 				"text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5",
		["Accept-Charset"]="ISO-8859-1,utf-8;q=0.7,*;q=0.7",
		["Accept-Encoding"]="gzip,deflate",
		["Accept-Language"]="en-us;q=0.8,en-en;q=0.5,en;q=0.3",
		["Host"]="mydomain.com",
		["User-Agent"]="Mozilla/5.0 ..."
	},
	env={ --[[ Depends on if we attract raw url or physical path ]] },
	content={ --[[ The content goes here ]] },
	status={ --[[ A table for mod_status/collecting statistics ]] },
	stat=function(filename) ...1 end
}

-- for magnet.attract-raw-url-to
lighty.env = {
	["uri.path"]="/path/to/file.html"
	["uri.path-raw"]="/path/to/file.html"
	["uri.scheme"]="http"
	["uri.authority"]="mydomain.com"
	["request.uri"]="/path/to/file.html"
	["request.orig-uri"]="/path/to/file.html"
}

-- for magnet.attract-physical-path-to
lighty.env = table.concat(lighty.env, {
	["physical.path"]="/var/www/docroot/path/to/file.html"
	["physical.rel-path"]="/path/to/file.html"
	["physical.doc-root"]="/var/www/docroot"
})
