-- app.lua: cache a PHP application for 5 minutes
php_path = "/app.php"
cache_dir = lighty.env["physical.doc-root"] .. "/cache/"
cache_time = 300 -- 300 seconds = 5 minutes

path = lighty.env["physical.rel-path"]
s = lighty.stat(cache_dir .. path)

if s ~= nil then -- not in cache, call out to PHP
	lighty.env["request.uri"] = php_path
	return lighty.RESTART_REQUEST
end

if s[8] + cache_time > os.time() then -- too old, call out to PHP
	lighty.env["request.uri"] = php_path
	return lighty.RESTART_REQUEST	
end

lighty.header["Content-Type"] = "text/html"
lighty.content = {{ filename = cache_dir .. path }}
return 200
