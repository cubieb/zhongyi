#!/usr/bin/python
#run from document root, pipe into URLs file. For example:
# /path/to/docroot$ crawl.py > urls
import os, re, sys

hostname = "http://localhost/"
for (root, dirs, files) in os.walk("."):
  for name in files:
    filepath = os.path.join(root, name)
    print re.sub("\\./", hostname, filepath)