#!/bin/env python
# run with: makeips.py 1000 101.202.0.0 
# to create 1000 ip entries in the subnet 101.202.*.*
import random, sys

ips = {}

def makeip(subnet, ip=None):
	while ip is None or ips.get(ip):
		ip = ".".join(x != "0" and x or str(int(random.random()*256)) 
			for x in subnet.split("."))
	ips[ip] = 1
	return ip

def makeips(amount, subnet):
	maxips = 256 ** sum("0" == x for x in subnet.split("."))
	if maxips < amount:
		print "Can only fit %i ips in the subnet %s." % (maxips, subnet)
		amount = maxips
	ipfile = open("ips", "w")
	for i in xrange(amount):
		ipfile.write(makeip(subnet) + "\n")
	ipfile.close();

if __name__ == "__main__":
	try: makeips(argv[1], argv[2])
	except: print "usage: python makeips.py [amount] [subnet]"
