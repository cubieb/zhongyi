#!/bin/env python
import os

def toUserList(users):
	return "|".join(["user="+user for user in users.split(" ")])

def getGroups(groupFileName, groups):
	groupFile = open(groupFileName)
	groupDict = {}
	for groupLine in groupFile:
		group, users = groupLine.split(":")
		groupDict[group.strip()] = users.strip()
	return "|".join([toUserList(groupDict[group]) for group in groups.split(" ")])

for (root, dirs, files) in os.walk(path):
	if ".htaccess" in files:
		filepath = os.path.join(root, ".htaccess")
		f = open(filepath)
		try:
			realm = root.rsplit(os.path.sep, 1)[1]
		except:
			realm = root
		try:
			# try some sensible defaults
			result = {"authtype":"Basic", "url":root, 
			"required":"nothing","realm":realm, 
			"authuserfile":os.path.join(root, ".htpasswd",
			"error":None}
			for line in f:
				try:
					tempdirective, arguments = line.split(" ", 1)
					directive = tempdirective.lower()
					result[directive] = arguments.strip('"')
				except:
					pass
			if result["required"].startswith("user"):
				result["required"] = toUserList(result["required"][5:])
			elif result["required"].startswith("group"):
				result["required"] = getGroups(result["authgroupfile"], result["required"][6:])
			if result["required"] != "nothing" and result["error"] is None:
				result["backend"] = {"Basic":"htpasswd", 
					"Digest":"htdigest"}[result["authtype"]]
				result["authtype"] = result["authtype"].lower()
				print """$HTTP["url"] =~ "%{url}s" {
	auth.backend = "${backend}s"
	auth.backend.${backend}s.userfile = "${authuserfile}s"
	auth.require = ( "/" => (
		"method" => "${authtype}s", 
		"realm" => "${realm}s",
		"require" => "${required}s"
	) )
}"""
		finally:
			f.close()
