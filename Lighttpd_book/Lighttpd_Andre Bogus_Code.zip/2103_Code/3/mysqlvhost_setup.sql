GRANT SELECT ON domains.* TO lighttpd@localhost
IDENTIFIED BY '********';
CREATE DATABASE domains;
USE domains;
CREATE TABLE domains (
domain VARCHAR(64) not null primary key,
document_root VARCHAR(256) not null);