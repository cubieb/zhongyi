# Add a domain
INSERT INTO domains
VALUES ('subdomain.ourdomain.net', '/var/www/sub1');

# Move a domain to another directory
UPDATE domains SET document_root = '/var/www/subdomain'
WHERE domain = 'subdomain.ourdomain.net';

# Delete a domain
DELETE FROM domains WHERE domain='subdomain.ourdomain.net';

# Change a domain name by deleting the old and adding a new entry or
UPDATE domains SET domain='newdomain.ourdomain.net' 
WHERE domain='olddomain.ourdomain.net'
