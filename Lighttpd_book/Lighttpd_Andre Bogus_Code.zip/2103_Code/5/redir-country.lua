-- redir-country.lua mod_magnet script
-- redirect-by-country, default to "us"
local countryCode = string.lower(lighty.env("GEOIP_COUNTRY_CODE") or "us")
lighty.header["Location"] = string.gsub(lighty.env["request.uri"] or "",
  "^(www%.)?", countryCode .. ".")
return 302