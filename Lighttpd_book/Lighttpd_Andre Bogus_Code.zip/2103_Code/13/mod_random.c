#include <stdlib.h>

#include "buffer.h"
#include "base.h"
#include "plugin.h"

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

typedef struct {
	unsigned int max;
} plugin_config;

typedef struct {
	PLUGIN_DATA;
	plugin_config **config_storage;
	plugin_config conf;
} plugin_data;

INIT_FUNC(mod_random_init) {
	plugin_data *p;
	UNUSED(srv);
	p = calloc(1, sizeof(*p));
	return p;
}

FREE_FUNC(mod_random_free) {
	plugin_data *p = p_d;
	UNUSED(srv);
	if (!p) return HANDLER_GO_ON;
	if (p->config_storage) {
		size_t i;
		for (i = 0; i < srv->config_context->used; i++) {
			plugin_config *s = p->config_storage[i];
			if (!s) continue;
			free(s);
		}
		free(p->config_storage);
	}
	free(p);
	return HANDLER_GO_ON;
}

SETDEFAULTS_FUNC(mod_random_set_defaults) {
	plugin_data *p = p_d;
	size_t i;
	config_values_t cv[] = {
		{"random.max", NULL, T_CONFIG_INT, T_CONFIG_SCOPE_CONNECTION},
		{NULL, NULL, T_CONFIG_UNSET, T_CONFIG_SCOPE_UNSET}
	};
	if (!p) return HANDLER_ERROR;
	p->config_storage = calloc(1, srv->config_context->used * 
			sizeof(specific_config *));
	for (i = 0; i < srv->config_context->used; i++) {
		plugin_config *s;
		s = calloc(1, sizeof(plugin_config));
		cv[0].destination = s;
		p->config_storage[i] = s;
		if (0 != config_insert_values_global(srv, ((data_config *)
				srv->config_context->data[i])->value, cv)) {
			return HANDLER_ERROR;
		}
	}
	return HANDLER_GO_ON;
}
static int mod_random_patch_connection(server *srv, connection *con,
		plugin_data *p) {
	size_t i, j;
	plugin_config *s = p->config_storage[0];
	PATCH_OPTION(max);
	for (i = 1; i < srv->config_context->used; i++) {
		data_config *dc = (data_config *)srv->config_context->data[i];
		s = p->config_storage[i];
		if (!config_check_cond(srv, con, dc)) continue;
		for (j = 0; j < dc->value->used; j++) {
			data_unset *du = dc->value->data[j];
			if (buffer_is_equal_string(du->key,
					CONST_STR_LEN("random.max"))) {
				PATCH_OPTION(max);
			}
		}
	}
	return 0;
}

URIHANDLER_FUNC(mod_random_uri_handler) {
	plugin_data *p = p_d;
	long r;
	UNUSED(srv);
	mod_random_patch_connection(srv, con, p);
	if (p->conf.max == 0) return HANDLER_GO_ON;
	/* get random value, shamelessly copied from "man rand" :-) */
	r = (long)((1.0 * p->conf.max) * (rand() / (RAND_MAX + 1.0)));
	buffer_append_long(con->physical.path, r);
	return HANDLER_GO_ON;
}

int mod_random_plugin_init(plugin *p) {
	p->version = LIGHTTPD_VERSION_ID;
	p->name = buffer_init_string("random");
	p->init = mod_random_init;
	p->handle_physical = mod_random_uri_handler;
	p->set_defaults = mod_random_set_defaults;
	p->cleanup = mod_random_free;
	p->data = NULL;
	return 0;
}