#include "log.h"
#include "stream.h"
#include "plugin.h"

/* First, we include needed header files and define our plugin_config
 * and data structure, as seen above.
 */
typedef struct {
	buffer *html_doctype;
	buffer *frameset_doctype;
} plugin_config;

typedef struct {
	PLUGIN_DATA;
	plugin_config **config_storage;
	plugin_config conf;
} plugin_data;

/* Our usual init function to claim the plugin data memory. */
INIT_FUNC(mod_doctype_init) {
	plugin_data *p;
	p = calloc(1, sizeof(*p));
	return p;
}

/* Helper function for mod_doctype_free, free a single plugin_config.
 */
void mod_doctype_freeconf(plugin_config *c) {
	if (!c) return; /* beware of the null value */
	if (c->html_doctype) buffer_free(c->html_doctype);
	if (c->frameset_doctype) buffer_free(c->frameset_doctype);
	free(c);
}

/* Our usual free function to let go of the memory for configuration.
	 */
FREE_FUNC(mod_doctype_free) {
	plugin_data *p = p_d;
	UNUSED(srv);
	if (!p) return HANDLER_GO_ON;
	mod_doctype_freeconf(&(p->conf));
	if (p->config_storage) {
		size_t i; /* iterate over contexts, free plugin_configs */
		for (i = 0; i < srv->config_context->used; i++) {
			plugin_config *s = p->config_storage[i];
			mod_doctype_freeconf(s);
		}
		free(p->config_storage); /* free the storage array */
	}
	free(p); /* free our plugin_data struct */
	return HANDLER_GO_ON;
}

/* The set_defaults function also contains nothing surprising */
SETDEFAULTS_FUNC(mod_doctype_set_defaults) {
	plugin_data *p = p_d;
	size_t i;
	config_values_t cv[] = { /* name, destination, type, scope */
		{"doctype.html", NULL, T_CONFIG_STRING,
			T_CONFIG_SCOPE_CONNECTION},
		{"doctype.frameset", NULL, T_CONFIG_STRING,
			T_CONFIG_SCOPE_CONNECTION},
		{NULL, NULL, T_CONFIG_UNSET, T_CONFIG_SCOPE_UNSET}
	};
	if (!p) return HANDLER_ERROR;

	p->config_storage = calloc(1, srv->config_context->used * 
			sizeof(specific_config *));
	for (i = 0; i < srv->config_context->used; i++) {
		plugin_config *s;
		s = calloc(1, sizeof(plugin_config));
		s->html_doctype = buffer_init();
		s->frameset_doctype = buffer_init();
		cv[0].destination = s->html_doctype;
		cv[1].destination = s->frameset_doctype;
		p->config_storage[i] = s;
		if (0 != config_insert_values_global(srv, ((data_config *)
				srv->config_context->data[i])->value, cv)) {
			return HANDLER_ERROR;
		}
	}
	return HANDLER_GO_ON;
}

/* The usual patch_connection function � nothing new here
 */
#define PATCH(x) p->conf.x = s->x;
static int mod_doctype_patch_connection(server *srv, connection *con, 
		plugin_data *p) {
	size_t i, j;
	plugin_config *s = p->config_storage[0];
	PATCH(html_doctype);
	PATCH(frameset_doctype);
	for (i = 1; i < srv->config_context->used; i++) {
		data_config *dc = (data_config *)srv->config_context->data[i];
		s = p->config_storage[i];
		if (!config_check_cond(srv, con, dc)) continue;
		for (j = 0; j < dc->value->used; j++) { /* get all values */
			data_unset *du = dc->value->data[j];
			if (buffer_is_equal_string(du->key,
					CONST_STR_LEN("doctype.html"))) {
				PATCH(html_doctype); /* set html_doctype, if found */
			} else if (buffer_is_equal_string(du->key, 
					CONST_STR_LEN("doctype.frameset"))) {
				PATCH(frameset_doctype); /* set frameset_doctype */
			}
		}
	}
	return 0;
}
#undef PATCH

/* A helper function to determine if a html file contains a frameset.
 * Uses a stream to peek at the file contents.
 */
static int mod_doctype_is_frameset(server *srv, buffer *path) {
	stream s;
	int result;
	if (-1 == stream_open(&s, path)) {
		log_error_write(srv, __FILE__, __LINE__, "sb", "stream-open: ",
			path);
		return 0; /* defaulting to no frameset */
	}
	result = !strstr("<frameset", s.start); /* search for frameset */
	stream_close(&s); /* close the stream, release resources */
	return result;
}

/* Our physical path handling function.
 */
URIHANDLER_FUNC(mod_doctype_physical_path) {
	plugin_data *p = p_d;
	size_t i;
	if (con->physical.path->used == 0) return HANDLER_GO_ON;
	mod_doctype_patch_connection(srv, con, p);
	for (i = 0; i < p->conf.html_doctype->used; i++) {
		data_string *ds = (data_string *)p->conf.html_doctype;
		buffer *doctype;
		if (ds->value->used == 0) continue;
		if (mod_doctype_is_frameset(srv, con->physical.path)) {
			doctype = p->conf.frameset_doctype;
		} else {
			doctype = p->conf.html_doctype;
		}
		chunkqueue_append_buffer(con->write_queue, doctype);
		return HANDLER_GO_ON; /* let mod_staticfile do the rest */
	}
	return HANDLER_GO_ON;
}

/* Here is our basic init function. No surprise here, either.
 */
int mod_doctype_plugin_init(plugin *p) {
	p->version = LIGHTTPD_VERSION_ID;
	p->name = buffer_init_string("doctype");
	
	p->init = mod_doctype_init;
	p->handle_subrequest_start = mod_doctype_physical_path;
	p->set_defaults = mod_doctype_set_defaults;
	p->cleanup = mod_doctype_free;
	p->data = NULL;
	return 0;
}
