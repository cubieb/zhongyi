#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "base.h"
#include "log.h"
#include "buffer.h"

#include "plugin.h"

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

/**
 * this is a helloworld for a lighttpd plugin
 */

typedef struct {
	unsigned short boolean_value; /* e.g. our.fun=enable */
	unsigned short short_value; /* e.g. our.port=80 */
	unsigned int int_value; /* wherever we may need one */
	buffer *string_value; /* e.g. we.love="Lighttpd" */
	array *array_value; /* e.g. our.array=("a", "b") or ("a"=>"b") */
	/* be sure to include buffer.h and array.h */
} plugin_config;

/* plugin config for all request/connections */
typedef struct {
	PLUGIN_DATA;
	plugin_config **config_storage;
	plugin_config conf;
} plugin_data;

/* init the plugin data */
INIT_FUNC(mod_helloworld_init) {
	plugin_data *p;
	p = calloc(1, sizeof(*p));
	log_trace("Hello, World");
	return p;
}

/* detroy the plugin data */
FREE_FUNC(mod_helloworld_free) {
	plugin_data *p = p_d;
	UNUSED(srv);
	if (!p) return HANDLER_GO_ON;
	if (p->config_storage) {
		size_t i;
		for (i = 0; i < srv->config_context->used; i++) {
			plugin_config *s = p->config_storage[i];
			if (!s) continue;
			/*	we need to free string/array values with the
				respective function */
			if (s->string_value) buffer_free(s->string_value);
			if (s->array_value) array_free(s->array_value);
			/* now we can free the plugin_config */
			free(s);
		}
		free(p->config_storage);
	}
	free(p);
	return HANDLER_GO_ON;
}

SETDEFAULTS_FUNC(mod_helloworld_set_defaults) {
	plugin_data *p = p_d;
	size_t i;
	config_values_t cv[] = {
		/* name, destination (set later), type, scope */
		{"our.fun", NULL, T_CONFIG_BOOLEAN, T_CONFIG_SCOPE_CONNECTION},
		{"our.port", NULL, T_CONFIG_SHORT, T_CONFIG_SCOPE_CONNECTION},
		{"our.number", NULL, T_CONFIG_INT, T_CONFIG_SCOPE_CONNECTION},
		{"we.love", NULL, T_CONFIG_STRING, T_CONFIG_SCOPE_CONNECTION},
		{"our.set", NULL, T_CONFIG_ARRAY, T_CONFIG_SCOPE_CONNECTION},
		{NULL, NULL, T_CONFIG_UNSET, T_CONFIG_SCOPE_UNSET}
		/* needs to end with a NULL entry */
	};
	if (!p) return HANDLER_ERROR;

	p->config_storage = calloc(1, srv->config_context->used * 
			sizeof(specific_config *));
	for (i = 0; i < srv->config_context->used; i++) {
		plugin_config *s;
		s = calloc(1, sizeof(plugin_config));
		s->string_value = buffer_init();
		s->array_value = array_init();
		/* set the destinations to our new plugin_config */
		cv[0].destination = s->boolean_value;
		cv[1].destination = s->short_value;
		cv[2].destination = s->int_value;
		cv[3].destination = s->string_value;
		cv[4].destination = s->array_value;
		p->config_storage[i] = s;
		/* let Lighttpd do the rest */
		if (0 != config_insert_values_global(srv, ((data_config *)
				srv->config_context->data[i])->value, cv)) {
			return HANDLER_ERROR;
		}
	}
	return HANDLER_GO_ON;
}

#define USED(n) (buffer_is_equal_string(du->key, CONST_STR_LEN(n)))

static int mod_helloworld_patch_connection(server *srv, 
		connection *con, plugin_data *p) {
	size_t i, j;
	plugin_config *s = p->config_storage[0];

	/* default to global context, one PATCH_OPTION per option */
	PATCH_OPTION(boolean_value);
	PATCH_OPTION(short_value);
	PATCH_OPTION(int_value);
	PATCH_OPTION(string_value);
	PATCH_OPTION(array_value);
	/* Go through all contexts (but global) */
	for (i = 1; i < srv->config_context->used; i++) {
		data_config *dc = (data_config *)srv->config_context->data[i];
		s = p->config_storage[i];
		if (!config_check_cond(srv, con, dc)) continue;
		/* Got matching context, enter the given values */
			for (j = 0; j < dc->value->used; j++) {
			data_unset *du = dc->value->data[j];
			/* if the option was set in this context, use it */
			if (USED("our.fun")) PATCH_OPTION(boolean_value);
			if (USED("our.port")) PATCH_OPTION(short_value);
			if (USED("our.number")) PATCH_OPTION(int_value);
			if (USED("we.love")) PATCH_OPTION(string_value);
			if (USED("our.set")) PATCH_OPTION(array_value);
		}
	}
	return 0;
}
#undef USED

int mod_helloworld_plugin_init(plugin *p) {
	p->version     = LIGHTTPD_VERSION_ID;
	p->name        = buffer_init_string("helloworld");
	p->init        = mod_helloworld_init;
	p->cleanup     = mod_helloworld_free;
	p->data        = NULL;
	return 0;
}
