# mod_doctype.lua
local p = lighty.env["physical.doc-root"] + lighty.env["request.uri"]
local f = io.open(p, "r")
if f:read("*a"):find("<frameset", 0, true) then
	lighty.content = {'<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01\
Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">', {filename=path}}
else
	lighty.content = {'<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01\
Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">', {filename=path}}
end
f:close()
return 200