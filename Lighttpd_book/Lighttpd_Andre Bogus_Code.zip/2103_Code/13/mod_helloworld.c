#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "base.h"
#include "log.h"
#include "buffer.h"

#include "plugin.h"

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

/**
 * this is a helloworld for a lighttpd plugin
 */

/* plugin config for all request/connections */
typedef struct {
	PLUGIN_DATA;
} plugin_data;

/* init the plugin data */
INIT_FUNC(mod_helloworld_init) {
	plugin_data *p;
	p = calloc(1, sizeof(*p));
	log_trace("Hello, World");
	return p;
}

/* detroy the plugin data */
FREE_FUNC(mod_helloworld_free) {
	plugin_data *p = p_d;
	UNUSED(srv);
	if (p) free(p);
	return HANDLER_GO_ON;
}

int mod_helloworld_plugin_init(plugin *p) {
	p->version     = LIGHTTPD_VERSION_ID;
	p->name        = buffer_init_string("helloworld");
	p->init        = mod_helloworld_init;
	p->cleanup     = mod_helloworld_free;
	p->data        = NULL;
	return 0;
}
