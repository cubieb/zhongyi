#!/usr/bin/python
import mimetypes
mimetypes.init()
keys = mimetypes.types_map.keys();
keys.sort(key=lambda x: -len(x))
m = open("mime-types.conf", "w")
m.write("mimetype.assign = (%s)\n"%(",\n".join(
	'"%s" => "%s"'%(key, mimetypes.types_map[key])
	for key in keys)))
m.close()
