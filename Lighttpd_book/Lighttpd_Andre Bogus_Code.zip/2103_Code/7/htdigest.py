#!/usr/bin/python
# htdigest.py [user] [realm] [password]
import sys, md5
a = sys.argv
print a[1] + ":" + a[2] + ":" + md5.new(a[1] + a[2] + a[3]).hexdigest() 