#!/bin/bash
# htdigest.sh � create a htdigest entry
# usage: htdigest.sh [username] [realm] [password]
echo $1:$2:$(echo $1:$2:$3 | md5sum | cut -b -32)
