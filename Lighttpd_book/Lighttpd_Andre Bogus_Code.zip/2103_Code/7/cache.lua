-- let us assume that our application writes temporary files into /var/tmp/lighttpd-cache
local p = "/var/tmp/lighttpd-cache/" .. lighty.env["physical.path"]

if lighty.stat(p) ~= nil then
  output_include = { { filename = p } }
  return 200
else
  return lighty.RESTART_REQUEST
end
